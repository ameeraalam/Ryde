import {StyleSheet} from "react-native";

const styles = StyleSheet.create({
  homeTextOnNavbar: {
		justifyContent:'center',
		alignItems:'center'
  }
});

module.exports = styles;
